//
//  ViewController.m
//  NilSafe
//
//  Created by songjc on 16/10/13.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "ViewController.h"
#import "AFNetworking.h"
#import "TestModel.h"
#import "NSString+NilSafe.h"

@interface ViewController ()

@property (strong, nonatomic) IBOutlet UILabel *label;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    NSString *testString = nil;
    
    self.label.text = [NSString NilSafeWithString:testString];
    
    
    
    
    
    
    
    TestModel *model = [[TestModel alloc]init];
    
    [model setValue:nil forKey:@"name"];
    self.label.text = model.name;

    [self loadAllDataSoure];
}

#pragma mark----加载所有的w数据----

-(void)loadAllDataSoure{

    AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc]init];
    
    manager.responseSerializer  = [AFHTTPResponseSerializer serializer];
    
    [manager POST:[NSString stringWithFormat:@"%@%@",@"www.baidu.com/",@"kehu!Kehulist.action"] parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        
        if (nil != responseObject) {
            
            NSDictionary *resultDic = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
            
            TestModel *model = [[TestModel alloc]init];
            
            [model setValuesForKeysWithDictionary:resultDic];
            
        }
        
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
        NSLog(@"服务器相关问题会执行这个block块");

    }];
    
    
    
}

@end
