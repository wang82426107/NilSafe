//
//  NSString+NilSafe.h
//  Electronic
//
//  Created by songjc on 16/5/27.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (NilSafe)

+(NSString *)NilSafeWithString:(NSString *)string;


@end
