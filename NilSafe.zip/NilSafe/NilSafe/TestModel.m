//
//  TestModel.m
//  NilSafe
//
//  Created by songjc on 16/10/13.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "TestModel.h"

@implementation TestModel

-(void)setValue:(id)value forUndefinedKey:(NSString *)key{


}

-(void)setValue:(id)value forKey:(NSString *)key{

    if (value == nil) {
        value = @"无";
    }

    [super setValue:value forKey:key];
    

}


@end
