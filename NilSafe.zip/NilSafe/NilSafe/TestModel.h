//
//  TestModel.h
//  NilSafe
//
//  Created by songjc on 16/10/13.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TestModel : NSObject

@property(nonatomic,strong)NSString *name;

@property(nonatomic,strong)NSString *gender;

@property(nonatomic,strong)NSString *address;


@end
