//
//  NSString+NilSafe.m
//  Electronic
//
//  Created by songjc on 16/5/27.
//  Copyright © 2016年 Don9. All rights reserved.
//

#import "NSString+NilSafe.h"

@implementation NSString (NilSafe)

+(NSString* )NilSafeWithString:(NSString *)string{

    

    if (string == nil) {
        return [NSString stringWithFormat:@"无"];
    }else{
    
    
        return string;
    
    }


}


@end
